#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
import json
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ClosureItem:
    item_id: str
    reviewer_issue: str
    status: str
    evidence_paths: tuple[str, ...]
    allowed_wording: str
    forbidden_wording: str
    notes: str


ITEMS: tuple[ClosureItem, ...] = (
    ClosureItem(
        "R01",
        "Pseudo-swarm is not real swarm validation",
        "limitation",
        ("docs/LIMITATIONS_Q1_UPGRADE.md", "docs/REAL_DETECTOR_VISDRONE.md"),
        "VisDrone is single-camera real-detector validation; controlled replay is a track-initiation extension.",
        "Validated real UAV swarm; replacement for synchronized multi-UAV datasets.",
        "No new multi-UAV dataset was added by design.",
    ),
    ClosureItem(
        "R02",
        "F1 gain is small; task should focus on false-new tracks",
        "supported",
        (
            "outputs/results/q1_final_plus/tradeoff_yolov8s/tradeoff_points.csv",
            "outputs/results/q1_final_plus/confidence_threshold_baseline_yolov8s/confidence_threshold_claim_safe.md",
        ),
        "The trust layer reduces false-new tracks with bounded F1 loss; matched-cleanliness comparisons are primary.",
        "The method improves overall tracking F1.",
        "YOLOv8s ByteTrack trust point reduces false-new tracks from 6838 to 4799.",
    ),
    ClosureItem(
        "R03",
        "Confidence threshold may explain the effect",
        "supported",
        (
            "outputs/results/q1_final_plus/confidence_threshold_baseline_yolov8s/confidence_threshold_summary.csv",
            "outputs/results/q1_final_plus/tradeoff_yolov8s/tradeoff_claim_safe.md",
        ),
        "At comparable false-new counts, trust preserves more F1 than the tested fixed confidence threshold.",
        "Trust universally dominates all confidence thresholds.",
        "The closest-cleanliness threshold 0.2 has lower F1 than the trust point.",
    ),
    ClosureItem(
        "R04",
        "Bayesian filter dominates the selected trust point",
        "limitation",
        (
            "outputs/results/q1_final_plus/simple_fusion_baselines/simple_fusion_summary.csv",
            "outputs/results/q1_final_plus/simple_fusion_baselines/simple_fusion_claim_safe.md",
        ),
        "Bayesian existence is the stronger numerical baseline in controlled replay; trust remains interpretable/no-label.",
        "Bayesian requires a learned model; trust beats simple fusion baselines.",
        "The generated claim-safe note explicitly records Bayesian dominance.",
    ),
    ClosureItem(
        "R05",
        "Simple fusion baselines are not cooperative perception SOTA",
        "closed",
        (
            "docs/LIMITATIONS_Q1_UPGRADE.md",
            "outputs/results/q1_final_plus/simple_fusion_baselines/simple_fusion_claim_safe.md",
        ),
        "Simple fusion rules are track-confirmation references, not CoBEVFusion/V2X-Real analogues.",
        "Simple fusion baselines represent cooperative perception SOTA.",
        "Full cooperative perception remains future work.",
    ),
    ClosureItem(
        "R06",
        "Min-rule guarantee does not cover temporal recovery",
        "partial",
        ("docs/REVIEWER_RESPONSE_CLAIM_SAFE_V18.md", "src/defense4uavswarm/q1_v5/trust_layer.py"),
        "Strict mode is noncompensatory; balanced mode uses temporal recovery and weakens the guarantee.",
        "The complete deployed decision rule is fully noncompensatory.",
        "Article text must keep strict and balanced modes separate.",
    ),
    ClosureItem(
        "R07",
        "Kinematic feature may be redundant",
        "supported",
        (
            "outputs/results/q1_final_plus/feature_ablation_final_controlled/feature_ablation_summary.csv",
            "outputs/results/q1_final_plus/feature_ablation_final_controlled/feature_ablation_claim_safe.md",
        ),
        "Geometry/temporal channels are the main practical contributors; kinematic support is not claimed as dominant.",
        "Each channel independently improves the result.",
        "The safe claim is feature-set trade-off, not guaranteed marginal utility for every channel.",
    ),
    ClosureItem(
        "R08",
        "Label scarcity does not prove the niche by F1 alone",
        "partial",
        (
            "outputs/results/q1_v5/calibration_staleness/calibration_staleness_summary.csv",
            "outputs/results/q1_v542/article_ready/table_label_scarcity.csv",
        ),
        "Low-label/stale-calibration niche is reported with caveats and supporting diagnostics.",
        "Trust is better than RF under all label budgets.",
        "Use calibration staleness/transfer evidence where available; do not overread label-scarcity F1.",
    ),
    ClosureItem(
        "R09",
        "Need map-contamination metrics, not only false-new count",
        "supported",
        (
            "src/defense4uavswarm/q1_v5/map_contamination.py",
            "outputs/results/q1_v5/operating_curves/bytetrack/operating_points_raw.csv",
            "outputs/results/q1_v542/article_ready/table_main_bytetrack.csv",
        ),
        "Report observed false-track occupancy and initiation precision as map-contamination proxies.",
        "Full tracker lifecycle occupancy is measured if only observed-row proxy exists.",
        "Current occupancy is an observed-detection-row proxy unless a lifecycle table is available.",
    ),
    ClosureItem(
        "R10",
        "Failure-case subgroup F1 is not standard object-level F1",
        "closed",
        (
            "outputs/results/q1_final_plus/failure_case_mining/failure_case_claim_safe.md",
            "outputs/results/q1_final_plus/failure_case_mining/failure_by_tracklet_persistence.csv",
        ),
        "Failure-case tables are candidate-level diagnostics.",
        "Subgroup diagnostics are standard object-level F1 or speed robustness.",
        "Motion proxy was replaced with tracklet-persistence bins.",
    ),
    ClosureItem(
        "R11",
        "Five seeds are not independent scene repeats",
        "partial",
        ("outputs/results/q1_final_plus/simple_fusion_baselines/simple_fusion_claim_safe.md",),
        "Repeated seeds are deterministic confidence-perturbation trials, not independent scenes.",
        "Five seeds prove independent simulation reproducibility.",
        "Use as sensitivity evidence only.",
    ),
    ClosureItem(
        "R12",
        "Algorithm must be self-contained",
        "partial",
        (
            "docs/REVIEWER_RESPONSE_CLAIM_SAFE_V18.md",
            "src/defense4uavswarm/q1_v5/trust_layer.py",
            "src/defense4uavswarm/q1_v5/initiation_gate.py",
        ),
        "Use the code-level contract and strict/balanced terminology for the algorithm description.",
        "Q=min(c,k,s) alone describes the full implementation.",
        "A paper pseudocode block still needs to be aligned with the code.",
    ),
    ClosureItem(
        "R13",
        "Runtime claims need decomposition",
        "partial",
        (
            "outputs/results/q1_final_plus/runtime_vectorization/runtime_vectorization_summary.csv",
            "outputs/results/q1_final_plus/runtime_vectorization/runtime_vectorization_claim_safe.md",
        ),
        "Runtime is implementation-dependent; vectorized aggregation is a microbenchmark over prepared features.",
        "5 ms/frame is generally acceptable for UAV deployment.",
        "Full detector/tracker runtime is not benchmarked here.",
    ),
    ClosureItem(
        "R14",
        "Reproducibility bundle must be auditable",
        "supported",
        (
            "outputs/bundles/Defense4UAVSwarm_q1_final_plus_v18_practice_bundle.zip",
            "reproducibility/q1_v5/manifest.json",
            "reproducibility/q1_v5/table_figure_mapping.csv",
        ),
        "The bundle provides scripts, selected outputs, manifest/checksum references, and claim-safe notes.",
        "The bundle alone contains raw images, detector JSON, and all external dependencies.",
        "Heavy inputs remain outside the slim bundle.",
    ),
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/results/q1_final_plus/review_closure")
    args = parser.parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    rows = [row_for(item) for item in ITEMS]
    csv_path = out / "review_closure_matrix.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)

    (out / "review_closure_matrix.md").write_text(markdown(rows), encoding="utf-8")
    (out / "run_metadata.json").write_text(json.dumps(metadata(), indent=2), encoding="utf-8")
    print(f"status=ok output={csv_path} rows={len(rows)}")


def row_for(item: ClosureItem) -> dict[str, str]:
    existing = [p for p in item.evidence_paths if Path(p).exists()]
    missing = [p for p in item.evidence_paths if not Path(p).exists()]
    evidence_status = "complete" if not missing else ("partial" if existing else "missing")
    return {
        "item_id": item.item_id,
        "reviewer_issue": item.reviewer_issue,
        "status": item.status,
        "evidence_status": evidence_status,
        "evidence_paths": ";".join(item.evidence_paths),
        "missing_evidence": ";".join(missing),
        "allowed_wording": item.allowed_wording,
        "forbidden_wording": item.forbidden_wording,
        "notes": item.notes,
    }


def markdown(rows: list[dict[str, str]]) -> str:
    lines = [
        "# Q1 Review Closure Matrix",
        "",
        "Statuses: closed/supported indicate evidence exists; partial/limitation indicate claim narrowing is required.",
        "",
        "| ID | Status | Evidence | Reviewer issue | Allowed wording | Forbidden wording |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            "| {item_id} | {status} | {evidence_status} | {reviewer_issue} | {allowed_wording} | {forbidden_wording} |".format(
                **{k: escape(v) for k, v in row.items()}
            )
        )
    lines.append("")
    return "\n".join(lines)


def escape(text: str) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ")


def metadata() -> dict[str, str]:
    return {
        "git_commit": git(["rev-parse", "HEAD"]),
        "branch": git(["branch", "--show-current"]),
        "status": "success",
    }


def git(args: list[str]) -> str:
    try:
        return subprocess.check_output(["git", *args], text=True).strip()
    except Exception:
        return "unavailable"


if __name__ == "__main__":
    main()
